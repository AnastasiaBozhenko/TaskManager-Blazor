CREATE PROCEDURE AddChecklistItem
    @TaskID INT,
    @Description NVARCHAR(255),
    @IsCompleted BIT
AS
BEGIN
    DECLARE @ChecklistItem INT;

    INSERT INTO ChecklistItem(TaskID, Description, IsCompleted)
    VALUES (@TaskID, @Description, @IsCompleted);

    SET @ChecklistItem = SCOPE_IDENTITY();

    SELECT @ChecklistItem AS ChecklistItem;
END;
GO