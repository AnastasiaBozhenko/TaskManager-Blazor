CREATE PROCEDURE SaveFile
    @TaskID INT,
    @FileName NVARCHAR(255),
    @FilePath NVARCHAR(255),
    @UploadDate DATETIME
AS
BEGIN
    DECLARE @DocumentID INT;

    INSERT INTO Document (TaskID, FileName, FilePath, UploadDate)
    VALUES (@TaskID, @FileName, @FilePath, @UploadDate);

    SET @DocumentID = SCOPE_IDENTITY();

    SELECT @DocumentID AS DocumentID;
END;
GO