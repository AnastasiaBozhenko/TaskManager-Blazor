CREATE PROCEDURE [dbo].[AddChatMessage]
    @TaskID INT,
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50), 
    @Message NVARCHAR(255),
    @DateSent DATETIME,
	@CurrentUser BIT
AS
BEGIN
    DECLARE @SenderID INT;

    SELECT @SenderID = PersonID
    FROM Person
    WHERE FirstName = @FirstName AND LastName = @LastName;

    IF @SenderID IS NULL
    BEGIN
        INSERT INTO Person(FirstName, LastName)
        VALUES (@FirstName, @LastName);

        SET @SenderID = SCOPE_IDENTITY();
    END;

    INSERT INTO ChatMessage (TaskID, SenderID, Message, DateSent, CurrentUser)
    VALUES (@TaskID, @SenderID, @Message, @DateSent, @CurrentUser);
END;
GO