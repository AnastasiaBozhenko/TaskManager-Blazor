CREATE PROCEDURE dbo.InsertTask
    @CompanyName NVARCHAR(MAX),
    @Description NVARCHAR(MAX),
    @CreatorFirstName NVARCHAR(MAX),
    @CreatorLastName NVARCHAR(MAX),
    @SolverFirstName NVARCHAR(MAX),
    @SolverLastName NVARCHAR(MAX),
    @ReportingDate DATETIME,
    @PriorityName NVARCHAR(MAX),
    @StatusName NVARCHAR(MAX),
    @Deadline DATETIME
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PriorityID INT;
    DECLARE @StatusID INT;

    SELECT @PriorityID = PriorityID FROM Priority WHERE PriorityName = @PriorityName;
    SELECT @StatusID = StatusID FROM Status WHERE StatusName = @StatusName;

    DECLARE @CreatorID INT;
    DECLARE @SolverID INT;
    DECLARE @CompanyID INT;

    SELECT @CreatorID = PersonID FROM Person WHERE FirstName = @CreatorFirstName AND LastName = @CreatorLastName;
    SELECT @SolverID = PersonID FROM Person WHERE FirstName = @SolverFirstName AND LastName = @SolverLastName;
    SELECT @CompanyID = CompanyID FROM Company WHERE CompanyName = @CompanyName;

    IF @CreatorID IS NULL
    BEGIN
        INSERT INTO Person (FirstName, LastName) VALUES (@CreatorFirstName, @CreatorLastName);
        SET @CreatorID = SCOPE_IDENTITY();
    END

    IF @SolverID IS NULL
    BEGIN
        INSERT INTO Person (FirstName, LastName) VALUES (@SolverFirstName, @SolverLastName);
        SET @SolverID = SCOPE_IDENTITY();
    END

    IF @CompanyID IS NULL
    BEGIN
        INSERT INTO Company (CompanyName) VALUES (@CompanyName);
        SET @CompanyID = SCOPE_IDENTITY();
    END;

    INSERT INTO Tasks (CompanyID, Description, CreatorID, SolverID, ReportingDate, PriorityID, StatusID, Deadline)
    VALUES (@CompanyID, @Description, @CreatorID, @SolverID, @ReportingDate, @PriorityID, @StatusID, @Deadline);

    SELECT SCOPE_IDENTITY() AS InsertedTaskID, * FROM Tasks WHERE TaskID = SCOPE_IDENTITY();
END;
GO