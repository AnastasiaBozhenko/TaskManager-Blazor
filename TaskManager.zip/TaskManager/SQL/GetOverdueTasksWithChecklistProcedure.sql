CREATE PROCEDURE GetOverdueTasksWithChecklist
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        T.TaskID, 
        C.CompanyID,
        R.PersonID AS CreatorID,
        RS.PersonID AS SolverID,
        PR.PriorityID,
        S.StatusID,
        PR.PriorityName AS 'Priority',
        C.CompanyName AS 'CompanyName',
        T.Description,
        S.StatusName AS 'Status',
        R.FirstName + ' ' + R.LastName AS 'Create by',
        RS.FirstName + ' ' + RS.LastName AS 'Assigned to',
        T.ReportingDate AS 'ReportingDate',
        T.Deadline,
        CL.ChecklistItemID,
        CL.TaskID
    FROM
        Tasks T
    JOIN
        Company C ON T.CompanyID = C.CompanyID
    JOIN
        Person R ON T.CreatorID = R.PersonID
    JOIN
        Person RS ON T.SolverID = RS.PersonID
    JOIN
        Priority PR ON T.PriorityID = PR.PriorityID
    JOIN
        Status S ON T.StatusID = S.StatusID
    LEFT JOIN
        ChecklistItem CL ON T.TaskID = CL.TaskID
    WHERE
        ((S.StatusID = 1 OR S.StatusID = 2) OR CL.TaskID IS NOT NULL) AND T.Deadline < GETDATE();
END;
GO