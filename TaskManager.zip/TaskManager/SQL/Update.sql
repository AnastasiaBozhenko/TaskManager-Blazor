CREATE OR ALTER PROCEDURE UpdateExistingTask
    @TaskID INT,
    @CompanyName NVARCHAR(MAX),
    @Description NVARCHAR(MAX),
    @CreatorFirstName NVARCHAR(MAX),
    @CreatorLastName NVARCHAR(MAX),
    @SolverFirstName NVARCHAR(MAX),
    @SolverLastName NVARCHAR(MAX),
    @ReportingDate DATETIME,
    @PriorityName NVARCHAR(MAX),
    @StatusName NVARCHAR(MAX),
    @Deadline DATETIME
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        DECLARE @PriorityID INT = (SELECT PriorityID FROM Priority WHERE PriorityName = @PriorityName);
        DECLARE @StatusID INT = (SELECT StatusID FROM Status WHERE StatusName = @StatusName);

        DECLARE @CreatorID INT = (SELECT PersonID FROM Person WHERE FirstName = @CreatorFirstName AND LastName = @CreatorLastName);
        DECLARE @SolverID INT = (SELECT PersonID FROM Person WHERE FirstName = @SolverFirstName AND LastName = @SolverLastName);
        DECLARE @CompanyID INT = (SELECT CompanyID FROM Company WHERE CompanyName = @CompanyName);

        IF @CreatorID IS NULL
        BEGIN
            INSERT INTO Person (FirstName, LastName) VALUES (@CreatorFirstName, @CreatorLastName);
            SET @CreatorID = SCOPE_IDENTITY();
        END

        IF @SolverID IS NULL
        BEGIN
            INSERT INTO Person (FirstName, LastName) VALUES (@SolverFirstName, @SolverLastName);
            SET @SolverID = SCOPE_IDENTITY();
        END

        IF @CompanyID IS NULL
        BEGIN
            INSERT INTO Company (CompanyName) VALUES (@CompanyName);
            SET @CompanyID = SCOPE_IDENTITY();
        END;

        UPDATE Tasks
        SET
            CompanyID = @CompanyID,
            Description = @Description,
            CreatorID = @CreatorID,
            SolverID = @SolverID,
            ReportingDate = @ReportingDate,
            PriorityID = @PriorityID,
            StatusID = @StatusID,
            Deadline = @Deadline
        WHERE
            TaskID = @TaskID;
        RETURN 1;
    END TRY
    BEGIN CATCH
        RETURN 0;
    END CATCH;
END;