INSERT INTO Priority (PriorityName) VALUES ('Low'), ('Medium'), ('High');
GO

INSERT INTO Status (StatusName) VALUES ('New'), ('In Progress'), ('Done');
GO

SET IDENTITY_INSERT Company ON;
INSERT INTO Company (CompanyID, CompanyName) VALUES (1, 'Company A'), (2, 'Company B'), (3, 'Company C');
GO

INSERT INTO Person (FirstName, LastName) VALUES ('Peter', 'Doe'), ('Jane', 'Grey'), ('Bob', 'Smith'), ('John', 'Snow'), ('Olivia', 'White');
GO


INSERT INTO Tasks (CompanyID, Description, RequesterID, ResolverID, ReportingDate, PriorityID, StatusID, Deadline)
VALUES
    (1, 'Develop new website', 4, 2, '2023-01-10', 3, 3, '2023-02-28'),
    (2, 'Create marketing campaign', 3, 2, '2023-02-15', 1, 1, '2023-03-15'),
    (3, 'Review financial reports', 1, 5, '2023-03-01', 2, 2, '2023-03-31'),
    (2, 'Install new software', 3, 2, '2023-04-05', 3, 3, '2023-04-30'),
    (1, 'Customer support training', 4, 5, '2023-05-10', 1, 1, '2023-06-15');


INSERT INTO ChatMessage (TaskID, SenderID, Message, Timestamp)
VALUES 
    (1, 1, 'Hi! When this be done?', '2023-01-02 12:30:00'),
    (2, 2, 'Hello!', '2023-02-02 13:45:00'),
    (3, 3, 'This is priority task to do.', '2023-03-02 14:15:00');
GO

INSERT INTO ChecklistItem (TaskID, Description, IsCompleted)
VALUES 
    (1, 'Checklist Item 1', 0),
    (1, 'Checklist Item 2', 1),
	(2, 'Checklist Item 1', 0),
    (2, 'Checklist Item 2', 1),
	(3, 'Checklist Item 1', 0),
    (3, 'Checklist Item 2', 1),
    (3, 'Checklist Item 3', 0);
GO
