﻿using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public class Priority
{
    [Key]
    public int PriorityID { get; set; }

    [Required]
    public string PriorityName { get; set; }

}