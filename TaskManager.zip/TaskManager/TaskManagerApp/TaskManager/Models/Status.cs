﻿using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public class Status
{
    [Key]
    public int StatusID { get; set; }

    [Required]
    public string StatusName { get; set; }
}