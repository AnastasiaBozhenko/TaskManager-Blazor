﻿using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public class ChecklistItem
{
    [Key]
    public int ChecklistItemID { get; set; }
    public int TaskID { get; set; }
    public string Description { get; set; }
    public bool IsCompleted { get; set; }

    public TaskItem Task { get; set; }
}