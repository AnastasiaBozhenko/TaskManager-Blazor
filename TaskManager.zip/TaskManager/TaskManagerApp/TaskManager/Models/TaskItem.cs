﻿using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using System.ComponentModel.DataAnnotations;
using System.Reflection.Metadata;
using System;

namespace TaskManager.Models;

public class TaskItem
{
    [Key]
    public int TaskID { get; set; }

    [Required]
    [StringLength(50, ErrorMessage = "Description is too long.")]
    [MinLength(5, ErrorMessage = "Description is too short.")]
    public string Description { get; set; }
    public int CompanyID { get; set; }
    public int CreatorID { get; set; }
    public int SolverID { get; set; }
    public int PriorityID { get; set; }
    public int StatusID { get; set; }

    [Required]
    public DateTime? Deadline { get; set; }
    [Required]
    public DateTime? ReportingDate { get; set; }

    public Company Company { get; set; }
    public Person Creator { get; set; }
    public Person Solver { get; set; }

    public Priority Priority { get; set; }
    public Status Status { get; set; }

    public List<ChatMessage> ChatMessages { get; set; } = new List<ChatMessage>();
    public List<UploadedFile> UploadedFiles { get; set; } = new List<UploadedFile>();
    public List<ChecklistItem> ChecklistItems { get; set; } = new List<ChecklistItem>();
}