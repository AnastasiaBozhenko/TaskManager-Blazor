﻿using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public class ChatMessage
{
    [Key]
    public int ChatMessageID { get; set; }
    public int TaskID { get; set; }
    public int SenderID { get; set; }
    public string Message { get; set; }
    public DateTime DateSent { get; set; }
    public bool CurrentUser { get; set; }

    public TaskItem Task { get; set; }
    public Person Sender { get; set; }

}