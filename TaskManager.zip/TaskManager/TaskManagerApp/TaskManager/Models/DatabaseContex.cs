﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace TaskManager.Models;

public class DatabaseContext : DbContext
{
    public DatabaseContext(DbContextOptions<DatabaseContext> options)
    : base(options)
    {
    }

    public DbSet<TaskItem> Tasks { get; set; }
    public DbSet<ChatMessage> ChatMessage { get; set; }
    public DbSet<UploadedFile> Document { get; set; }
    public DbSet<ChecklistItem> ChecklistItem { get; set; }
}