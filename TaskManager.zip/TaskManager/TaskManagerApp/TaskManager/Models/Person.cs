﻿using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public class Person
{
    [Key]
    public int PersonID { get; set; }

    [Required]
    [StringLength(15, ErrorMessage = "First Name is too long.")]
    [MinLength(2, ErrorMessage = "First Name is too short.")]
    public string FirstName { get; set; }

    [Required]
    [StringLength(15, ErrorMessage = "Last Name is too long.")]
    [MinLength(2, ErrorMessage = "Last Name is too short.")]
    public string LastName { get; set; }

    public string FullName => $"{FirstName} {LastName}";
}