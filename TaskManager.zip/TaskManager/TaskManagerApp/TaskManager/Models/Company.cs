﻿using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;

public class Company
{
    [Key]
    public int CompanyID { get; set; }

    [Required]
    [StringLength(15, ErrorMessage = "Company Name is too long.")]
    [MinLength(2, ErrorMessage = "Company Name is too short.")]
    public string CompanyName { get; set; }
}