﻿using System.ComponentModel.DataAnnotations;

namespace TaskManager.Models;
public class UploadedFile
{
    [Key]
    public int UploadedFileID { get; set; }
    public int TaskID { get; set; }
    public string FileName { get; set; }
    public string FilePath { get; set; }
    public DateTime UploadDate { get; set; }
    public TaskItem Task { get; set; }
}

