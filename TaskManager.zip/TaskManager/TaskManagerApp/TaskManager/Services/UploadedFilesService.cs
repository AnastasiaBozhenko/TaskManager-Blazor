﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Metadata;
using System.Threading.Tasks;
using TaskManager.Models;
using TaskManager.Services.Interfaces;

namespace TaskManager.Services;

public class UploadedFilesService : IUploadedFilesService
{
    private readonly DatabaseContext _context;

    public UploadedFilesService(DatabaseContext context)
    {
        _context = context;
    }

    public async Task<List<UploadedFile>> SaveFilesAsync(UploadedFile newFile, int taskId)
    {
        try
        {
            SqlParameter taskID = new SqlParameter("@TaskID", taskId);
            SqlParameter fileName = new SqlParameter("@FileName", newFile.FileName);
            SqlParameter filePath = new SqlParameter("@FilePath", newFile.FilePath);
            SqlParameter uploadDate = new SqlParameter("@UploadDate", newFile.UploadDate);

            var newUploadedFile = await _context.Document.FromSqlRaw(@"EXECUTE dbo.SaveFile @TaskID, @FileName, @FilePath, @UploadDate,",
                                                         taskID, fileName, filePath, uploadDate).ToListAsync();
            return newUploadedFile;
        }
        catch (Exception ex)
        {
            throw new CustomDataAccessException("Error uploading files.", ex);
        }
    }

    public async Task DeleteFilesItem(int fileID)
    {

    }

    public async Task<List<UploadedFile>> GetFilesByTaskId(int taskId)
    {
        var files = _context.Document
            .Include(file => file.Task)
            .Where(file => file.TaskID != null && file.TaskID == taskId)
            .ToList();

        return files;
    }
}
