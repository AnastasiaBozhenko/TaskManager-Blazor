﻿using TaskManager.Models;

namespace TaskManager.Services.Interfaces
{
    public interface IChecklistService
    {
        Task<List<ChecklistItem>> AddChecklistItemAsync(ChecklistItem newChecklistItem, int taskId);
        Task DeleteChecklistItem(int checklistItemID);
        Task<List<ChecklistItem>> GetChecklistByTaskId(int taskID);
    }
}