﻿using TaskManager.Models;

namespace TaskManager.Services.Interfaces;

public interface IMessagesService
{
    Task<List<ChatMessage>> AddMessageAsync(ChatMessage newMessage, int taskId);
    Task DeleteMessage(int chatMessageID);
    Task<List<ChatMessage>> GetMessagesByTaskId(int taskID);
}