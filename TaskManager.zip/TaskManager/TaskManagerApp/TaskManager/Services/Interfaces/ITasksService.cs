﻿using TaskManager.Models;

namespace TaskManager.Services.Interfaces;

public interface ITasksService
{
    Task<List<TaskItem>> AddTaskAsync(TaskItem newTask);
    Task DeleteTask(int taskID);
    Task<List<TaskItem>> GetAllTasksAsync();
    public List<TaskItem> GetTaskById(int taskId);
    Task<List<TaskItem>> UpdateTaskAsync(TaskItem task);
}
