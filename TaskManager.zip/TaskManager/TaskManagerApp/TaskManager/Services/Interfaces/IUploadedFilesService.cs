﻿using TaskManager.Models;

namespace TaskManager.Services.Interfaces
{
    public interface IUploadedFilesService
    {
        Task<List<UploadedFile>> SaveFilesAsync(UploadedFile newFile, int taskId);
        Task DeleteFilesItem(int fileID);
        Task<List<UploadedFile>> GetFilesByTaskId(int taskID);
    }
}