﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using TaskManager.Models;
using TaskManager.Services.Interfaces;

namespace TaskManager.Services;

public class ChecklistService : IChecklistService
{
    private readonly DatabaseContext _context;
    public ChecklistService(DatabaseContext context)
    {
        _context = context;
    }

    public async Task<List<ChecklistItem>> AddChecklistItemAsync(ChecklistItem newChecklistItem, int taskId)
    {
        try
        {
            SqlParameter taskID = new SqlParameter("@TaskID", taskId);
            SqlParameter description = new SqlParameter("@Description", newChecklistItem.Description);
            SqlParameter isCompleted = new SqlParameter("@IsCompleted", newChecklistItem.IsCompleted);

            var checklistItem = await _context.ChecklistItem.FromSqlRaw(@"EXECUTE dbo.AddChecklistItem @TaskID, @Description, @IsCompleted",
                                                         taskID, description, isCompleted).ToListAsync();
            return checklistItem;
        }
        catch (Exception ex)
        {
            throw new CustomDataAccessException("Error added new task.", ex);
        }
    }

    public async Task DeleteChecklistItem(int checklistItemID)
    {

    }

    public async Task<List<ChecklistItem>> GetChecklistByTaskId(int taskId)
    {
        var checklistItems = _context.ChecklistItem
            .Include(c => c.Task)
            .Where(c => c.TaskID != null && c.TaskID == taskId)
            .ToList();

        return checklistItems;
    }
}
