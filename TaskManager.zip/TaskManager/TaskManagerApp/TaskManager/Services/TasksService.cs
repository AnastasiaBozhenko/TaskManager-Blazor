﻿
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using TaskManager.Models;
using TaskManager.Services.Interfaces;

namespace TaskManager.Services;

public class TasksService : ITasksService
{
    private readonly DatabaseContext _context;
    public TasksService(DatabaseContext context)
    {
        _context = context;
    }

    public async Task<List<TaskItem>> AddTaskAsync(TaskItem newTask)
    {
        try
        {
            SqlParameter companyName = new SqlParameter("@CompanyName", newTask.Company.CompanyName);
            SqlParameter description = new SqlParameter("@Description", newTask.Description);
            SqlParameter creatorFirstName = new SqlParameter("@CreatorFirstName", newTask.Creator.FirstName);
            SqlParameter creatorLastName = new SqlParameter("@CreatorLastName", newTask.Creator.LastName);
            SqlParameter solverFirstName = new SqlParameter("@SolverFirstName", newTask.Solver.FirstName);
            SqlParameter solverLastName = new SqlParameter("@SolverLastName", newTask.Solver.LastName);
            SqlParameter reportingDate = new SqlParameter("@ReportingDate", newTask.ReportingDate);
            SqlParameter priorityName = new SqlParameter("@PriorityName", newTask.Priority.PriorityName);
            SqlParameter statusName = new SqlParameter("@StatusName", newTask.Status.StatusName);
            SqlParameter deadline = new SqlParameter("@Deadline", newTask.Deadline);

           var newTaskItem =  await _context.Tasks.FromSqlRaw(@"EXECUTE dbo.InsertTask @CompanyName, @Description, @CreatorFirstName, @CreatorLastName,
                                                        @SolverFirstName, @SolverLastName, @ReportingDate, @PriorityName, @StatusName, @Deadline",
                                                        companyName, description, creatorFirstName, creatorLastName, solverFirstName, solverLastName,
                                                        reportingDate, priorityName, statusName, deadline).ToListAsync();
            return newTaskItem;
        }
        catch (Exception ex)
        {
            throw new CustomDataAccessException("Error adding a task.", ex);
        }
    }

    public async Task DeleteTask(int taskID)
    {
        try
        {
            await _context.Database.ExecuteSqlInterpolatedAsync($"EXECUTE dbo.DeleteTaskById @TaskID={taskID}");
            return;
        }
        catch (Exception ex)
        {
            throw new CustomDataAccessException("Error deleting the task.", ex);
        }
    }

    public async Task<List<TaskItem>> GetAllTasksAsync()
    {
        try
        {
            List<TaskItem> tasks = _context.Tasks.FromSqlRaw("EXECUTE dbo.GetAllTasks").ToList();

            tasks = await _context.Tasks
            .Include(t => t.Company)
            .Include(t => t.Creator)
            .Include(t => t.Solver)
            .Include(t => t.Priority)
            .Include(t => t.Status)
            .ToListAsync();

            return tasks;
        }
        catch (Exception ex)
        {
            throw new CustomDataAccessException("Error fetching all tasks", ex);
        }
    }

    public List<TaskItem> GetTaskById(int taskId)
    {
       var tasks =  _context.Tasks
             .Include(t => t.Company)
             .Include(t => t.Creator)
             .Include(t => t.Solver)
             .Include(t => t.Priority)
             .Include(t => t.Status)
             .ToList();

        return tasks.Where(t => t.TaskID != null && t.TaskID == taskId).ToList();
    }

    public async Task<List<TaskItem>> UpdateTaskAsync(TaskItem task)
    {
        try
        {
            SqlParameter taskId = new SqlParameter("@TaskID", task.TaskID);
            SqlParameter companyName = new SqlParameter("@CompanyName", task.Company.CompanyName);
            SqlParameter description = new SqlParameter("@Description", task.Description);
            SqlParameter creatorFirstName = new SqlParameter("@CreatorFirstName", task.Creator.FirstName);
            SqlParameter creatorLastName = new SqlParameter("@CreatorLastName", task.Creator.LastName);
            SqlParameter solverFirstName = new SqlParameter("@SolverFirstName", task.Solver.FirstName);
            SqlParameter solverLastName = new SqlParameter("@SolverLastName", task.Solver.LastName);
            SqlParameter reportingDate = new SqlParameter("@ReportingDate", task.ReportingDate);
            SqlParameter priorityName = new SqlParameter("@PriorityName", task.Priority.PriorityName);
            SqlParameter statusName = new SqlParameter("@StatusName", task.Status.StatusName);
            SqlParameter deadline = new SqlParameter("@Deadline", task.Deadline);



            var newTaskItem = await _context.Tasks.FromSqlRaw(@"EXECUTE dbo.UpdateExistingTask @TaskID, @CompanyName, @Description, @CreatorFirstName, @CreatorLastName,
                                                        @SolverFirstName, @SolverLastName, @ReportingDate, @PriorityName, @StatusName, @Deadline",
                                                      taskId, companyName, description, creatorFirstName, creatorLastName, solverFirstName, solverLastName,
                                                       reportingDate, priorityName, statusName, deadline).ToListAsync();

            return newTaskItem;
        }
        catch (Exception ex)
        {
            throw new CustomDataAccessException("Error updating the task.", ex);
        }
    }

    public async Task<List<TaskItem>> GetOverdueTasksAsync()
    {
        try
        {
            var tasks = _context.Tasks
                .Include(t => t.Company)
                .Include(t => t.Creator)
                .Include(t => t.Solver)
                .Include(t => t.Priority)
                .Include(t => t.Status)
                .ToList();

            return tasks.Where(t => t.Status.StatusID != 3 && t.Deadline > DateTime.Now).ToList();
        }
        catch (Exception ex)
        {
            throw new CustomDataAccessException("Error fetching all tasks", ex);
        }
    }

    public async Task<List<TaskItem>> GetUnresolvedTasksAsync()
    {
        try
        {
            var tasks = _context.Tasks
                .Include(t => t.Company)
                .Include(t => t.Creator)
                .Include(t => t.Solver)
                .Include(t => t.Priority)
                .Include(t => t.Status)
                .ToList();

            return tasks.Where(t => t.Status.StatusID != 3).ToList();
        }
        catch (Exception ex)
        {
            throw new CustomDataAccessException("Error fetching all tasks", ex);
        }
    }

    public async Task<List<TaskItem>> GetOverdueTasksWithChecklistAsync()
    {
        try
        {
            //List<TaskItem> tasks = _context.Tasks.FromSqlRaw("EXECUTE dbo.GetOverdueTasksWithChecklist").ToList();

           var tasksWithChecklist = await _context.Tasks
            .Include(t => t.Company)
            .Include(t => t.Creator)
            .Include(t => t.Solver)
            .Include(t => t.Priority)
            .Include(t => t.Status)
            .Where(t => t.Status.StatusID != 3 && t.Deadline > DateTime.Now)
            .Where(t => _context.ChecklistItem.Any(ci => ci.TaskID == t.TaskID))
            .ToListAsync();

            var taskItems = tasksWithChecklist.Select(t => new TaskItem
            {
                TaskID = t.TaskID,
                ChecklistItems = t.ChecklistItems.ToList()
            }).ToList();

            return taskItems;
        }
        catch (Exception ex)
        {
            throw new CustomDataAccessException("Error fetching all tasks", ex);
        }
    }
}