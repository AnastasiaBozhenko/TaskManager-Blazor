﻿using Microsoft.AspNetCore.SignalR.Protocol;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using TaskManager.Models;
using TaskManager.Services.Interfaces;

namespace TaskManager.Services;

public class MessagesService : IMessagesService
{
    private readonly DatabaseContext _context;
    public MessagesService(DatabaseContext context)
    {
        _context = context;
    }

    public async Task<List<ChatMessage>> AddMessageAsync(ChatMessage newMessage, int taskId)
    {
        try
        {
            SqlParameter taskID = new SqlParameter("@TaskID", taskId);
            SqlParameter senderFirstName = new SqlParameter("@FirstName", newMessage.Sender.FirstName);
            SqlParameter senderLastName = new SqlParameter("@LastName", newMessage.Sender.LastName);
            SqlParameter message = new SqlParameter("@Message", newMessage.Message);
            SqlParameter dateSent = new SqlParameter("@DateSent", newMessage.DateSent);
            SqlParameter currentUser = new SqlParameter("@CurrentUser", newMessage.CurrentUser);

            var _newMessage = await _context.ChatMessage.FromSqlRaw(@"EXECUTE dbo.AddChatMessage @TaskID, @FirstName,@LastName, @Message, @DateSent, @CurrentUser",
                                                         taskID, senderFirstName, senderLastName, message, dateSent, currentUser).ToListAsync();
            return _newMessage;
        }
        catch (Exception ex)
        {
            throw new CustomDataAccessException("Error sending messages.", ex);
        }
    }

    public async Task DeleteMessage(int chatMessageID)
    {

    }

    public async Task<List<ChatMessage>> GetMessagesByTaskId(int taskId)
    {
        var messages = _context.ChatMessage
            .Include(message => message.Task)
            .Include(message => message.Sender)
            .Where(message => message.TaskID != null && message.TaskID == taskId)
            .ToList();

        return messages;
    }

}
