﻿namespace TaskManager.Services;

public class CustomDataAccessException : Exception
{
    public CustomDataAccessException()
    {
    }

    public CustomDataAccessException(string message)
        : base(message)
    {
    }

    public CustomDataAccessException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
