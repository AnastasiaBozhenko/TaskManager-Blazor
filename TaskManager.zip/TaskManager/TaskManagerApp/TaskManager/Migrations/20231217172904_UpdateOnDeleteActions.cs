﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TaskManager.Migrations
{
    /// <inheritdoc />
    public partial class UpdateOnDeleteActions : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Document_Tasks_TaskID",
                table: "Document");

            migrationBuilder.DropForeignKey(
                name: "FK_ChatMessage_Person_SenderID",
                table: "ChatMessage");

            migrationBuilder.DropForeignKey(
                name: "FK_ChatMessage_Tasks_TaskID",
                table: "ChatMessage");

            migrationBuilder.DropForeignKey(
                name: "FK_ChecklistItem_Tasks_TaskID",
                table: "ChecklistItem");

            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Company_CompanyID",
                table: "Tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Person_CreatorID",
                table: "Tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Person_SolverID",
                table: "Tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Priority_PriorityID",
                table: "Tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Status_StatusID",
                table: "Tasks");

            migrationBuilder.AddForeignKey(
                name: "FK_Document_Tasks_TaskID",
                table: "Document",
                column: "TaskID",
                principalTable: "Tasks",
                principalColumn: "TaskID",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ChatMessage_Person_SenderID",
                table: "ChatMessage",
                column: "SenderID",
                principalTable: "Person",
                principalColumn: "PersonID",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ChatMessage_Tasks_TaskID",
                table: "ChatMessage",
                column: "TaskID",
                principalTable: "Tasks",
                principalColumn: "TaskID",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ChecklistItem_Tasks_TaskID",
                table: "ChecklistItem",
                column: "TaskID",
                principalTable: "Tasks",
                principalColumn: "TaskID",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Company_CompanyID",
                table: "Tasks",
                column: "CompanyID",
                principalTable: "Company",
                principalColumn: "CompanyID",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Person_CreatorID",
                table: "Tasks",
                column: "CreatorID",
                principalTable: "Person",
                principalColumn: "PersonID",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Person_SolverID",
                table: "Tasks",
                column: "SolverID",
                principalTable: "Person",
                principalColumn: "PersonID",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Priority_PriorityID",
                table: "Tasks",
                column: "PriorityID",
                principalTable: "Priority",
                principalColumn: "PriorityID",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Status_StatusID",
                table: "Tasks",
                column: "StatusID",
                principalTable: "Status",
                principalColumn: "StatusID",
                onDelete: ReferentialAction.NoAction);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Document_Tasks_TaskID",
                table: "Document");

            migrationBuilder.DropForeignKey(
                name: "FK_ChatMessage_Person_SenderID",
                table: "ChatMessage");

            migrationBuilder.DropForeignKey(
                name: "FK_ChatMessage_Tasks_TaskID",
                table: "ChatMessage");

            migrationBuilder.DropForeignKey(
                name: "FK_ChecklistItem_Tasks_TaskID",
                table: "ChecklistItem");

            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Company_CompanyID",
                table: "Tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Person_CreatorID",
                table: "Tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Person_SolverID",
                table: "Tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Priority_PriorityID",
                table: "Tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Status_StatusID",
                table: "Tasks");

            migrationBuilder.AddForeignKey(
                name: "FK_Document_Tasks_TaskID",
                table: "Document",
                column: "TaskID",
                principalTable: "Tasks",
                principalColumn: "TaskID");

            migrationBuilder.AddForeignKey(
                name: "FK_ChatMessage_Person_SenderID",
                table: "ChatMessage",
                column: "SenderID",
                principalTable: "Person",
                principalColumn: "PersonID");

            migrationBuilder.AddForeignKey(
                name: "FK_ChatMessage_Tasks_TaskID",
                table: "ChatMessage",
                column: "TaskID",
                principalTable: "Tasks",
                principalColumn: "TaskID");

            migrationBuilder.AddForeignKey(
                name: "FK_ChecklistItem_Tasks_TaskID",
                table: "ChecklistItem",
                column: "TaskID",
                principalTable: "Tasks",
                principalColumn: "TaskID");

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Company_CompanyID",
                table: "Tasks",
                column: "CompanyID",
                principalTable: "Company",
                principalColumn: "CompanyID");

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Person_CreatorID",
                table: "Tasks",
                column: "CreatorID",
                principalTable: "Person",
                principalColumn: "PersonID");

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Person_SolverID",
                table: "Tasks",
                column: "SolverID",
                principalTable: "Person",
                principalColumn: "PersonID");

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Priority_PriorityID",
                table: "Tasks",
                column: "PriorityID",
                principalTable: "Priority",
                principalColumn: "PriorityID");

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Status_StatusID",
                table: "Tasks",
                column: "StatusID",
                principalTable: "Status",
                principalColumn: "StatusID");
        }
    }
}
